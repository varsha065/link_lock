<?php

include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `invoice` where `executive` = 0");

    //$businsess = mysqli_query($sql, $query);

    while($listbuss = mysqli_fetch_object($query)) {

        $invoicno = $listbuss->invoice_no;
        $iid = $listbuss->id;

        $getinfo = mysqli_query($sql, "SELECT * FROM `sales_import` where `invoice_no` = '$invoicno'");

        $listinfo = mysqli_fetch_object($getinfo);

        $clientname = $listinfo->executive;

        $getclient = mysqli_query($sql, "SELECT * FROM `executive` where `ename` = '$clientname'");

        $getclinfo = mysqli_fetch_object($getclient);

        //echo $invoicno.' - '.$clientname.' - '.$getclinfo->id.'<br>';
        $cid = $getclinfo->id;

        mysqli_query($sql, "UPDATE `invoice` SET `executive` = '$cid' where `id` = '$iid'");

    }
?>