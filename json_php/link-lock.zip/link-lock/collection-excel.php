<?php
$pagname = 'hide';
include('config.php');
include('header.php');

if (isset($_POST['submit'])) {
    if (isset($_FILES['uploadFile']['name']) && $_FILES['uploadFile']['name'] != "") {
        $allowedExtensions = array("xls", "xlsx", "csv");
        $ext = pathinfo($_FILES['uploadFile']['name'], PATHINFO_EXTENSION);

        $filename = $_FILES['uploadFile']['name'];
        $cdate = date('Y-m-d H:i:s');


        if (in_array($ext, $allowedExtensions)) {
            // Uploaded file
            $file = "upload/" . $_FILES['uploadFile']['name'];
            $isUploaded = copy($_FILES['uploadFile']['tmp_name'], $file);

            $filebk = "upload/collection_excel/" . time() . '_' . $_FILES['uploadFile']['name'];
            $isUploadedbk = copy($_FILES['uploadFile']['tmp_name'], $filebk);

            // check uploaded file
            if ($isUploaded) {

                $ufilename = time() . '_' . $_FILES['uploadFile']['name'];

                mysqli_query($sql, "INSERT INTO `invoice_import_record` (`excel_filename`, `created_on`, `excel_type`) VALUES ('$ufilename', '$cdate', 'collectionImport')");

                $insertid = mysqli_insert_id($sql);

                include('PHPExcel.php');

                try {
                    // load uploaded file
                    $objPHPExcel = PHPExcel_IOFactory::load($file);
                } catch (Exception $e) {
                    die('Error loading file "' . pathinfo($file, PATHINFO_BASENAME) . '": ' . $e->getMessage());
                }

                // Specify the excel sheet index
                $sheet = $objPHPExcel->getSheet(0);
                $total_rows = $sheet->getHighestRow();
                $highestColumn = $sheet->getHighestColumn();
                $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);

                //	loop over the rows
                for ($row = 1; $row <= $total_rows; ++$row) {
                    for ($col = 0; $col < $highestColumnIndex; ++$col) {
                        $cell = $sheet->getCellByColumnAndRow($col, $row);
                        $val = $cell->getValue();
                        $records[$row][$col] = $val;
                    }
                }

                $i = 1;
                foreach ($records as $row) {


                    $zone = isset($row[0]) ? $row[0] : '';
                    $state = isset($row[1]) ? $row[1] : '';
                    $city = isset($row[2]) ? $row[2] : '';
                    $account_name = isset($row[3]) ? $row[3] : '';
                    $from_zero = isset($row[4]) ? $row[4] : '';
                    $from_four_six = isset($row[5]) ? $row[5] : '';
                    $from_six_one = isset($row[6]) ? $row[6] : '';
                    $from_nine_one = isset($row[7]) ? $row[7] : '';
                    $from_twelve_one = isset($row[8]) ? $row[8] : '';
                    $from_fifteen_one = isset($row[9]) ? $row[9] : '';
                    $greaterthan_eighteen_zero = isset($row[10]) ? $row[10] : '';
                    $total_outstanding = isset($row[11]) ? $row[11] : '';
                    $credit_period = isset($row[12]) ? $row[12] : '';
                    $outstanding_due = isset($row[13]) ? $row[13] : '';
                    $received_during = isset($row[14]) ? $row[14] : '';


                    if ($i != 1) {

                        mysqli_query($sql, "INSERT INTO `collection_import` (`lot`, `zone`, `state`, `city`, `account_name`, `from_zero`, `from_four_six`, `from_six_one`, `from_nine_one`, `from_twelve_one`, `from_fifteen_one`,`greaterthan_eighteen_zero`, `total_outstanding`, `credit_period`, `outstanding_due`, `received_during`) VALUES ('$insertid', '$zone', '$state', '$city', '$account_name', '$from_zero', '$from_four_six', '$from_six_one', '$from_nine_one', '$from_twelve_one', '$from_fifteen_one', '$greaterthan_eighteen_zero', '$total_outstanding','$credit_period','$outstanding_due','$received_during')");


                    }

                    $i++;

                }

                /*echo "<br/>".$i." Records inserted in Database. <br /> <a href='newpdfloop.php?lot=".$insertid."'>Generate PDF</a>";*/

                //header('location:https://dms.mgfs.in/bulk_invoice/'.$insertid);

                //unlink($file);
            } else {
                echo '<span class="msg">File not uploaded!</span>';
            }
        } else {
            echo '<span class="msg">Please upload excel sheet.</span>';
        }
    } else {
        echo '<span class="msg">Please upload excel file.</span>';
    }
}
?>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Collection Excel</h1>

    <div class="row">

        <div class="col-xl-12 col-lg-12">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <!-- <h6 class="m-0 font-weight-bold text-primary">Upload Collection Excel</h6> -->
                    <div class="row" style="justify-content: space-between;">
                        <h6 class="m-0 font-weight-bold text-primary">Upload Collection Excel</h6>
                        <a href="https://project-uat.com/link-lock/upload/collection-sample.csv" download><button type="button" class="btn btn-sm btn-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                                class="bi bi-download" viewBox="0 0 16 16">
                                <path
                                    d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z">
                                </path>
                                <path
                                    d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z">
                                </path>
                            </svg>
                            Sample Excel
                        </button></a>
                    </div>
                </div>
                <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <input type="file" name="uploadFile" id="uploadFile">
                        <input type="submit" name="submit" value="Submit" class="btn btn-primary">
                    </form>
                </div>
            </div>
        </div>

    </div>

    <div class="row">

        <div class="col-xl-12 col-lg-12">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Imported List of Excel</h6>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Lot No.</th>
                                <th scope="col">File</th>
                                <th scope="col">Created Date</th>
                                <th scope="col">Uploaded Records</th>
                                <th scope="col">View Data</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $getallimport = mysqli_query($sql, "SELECT * FROM `invoice_import_record` where `excel_type` = 'collectionImport' and `deleted` != 1");

                            $y = 1;
                            while ($listimport = mysqli_fetch_object($getallimport)) {

                                $lotid = $listimport->id;

                                $getcountr = mysqli_query($sql, "SELECT * FROM `collection_import` where `lot` = '$lotid'");
                                $getrowcount = mysqli_num_rows($getcountr);
                                $newgetcountr = mysqli_fetch_object($getcountr);
                                $lotno = $newgetcountr->lot;

                                echo '<tr>
                                    <th scope="row">' . $y . '</th>
                                    <td>Lot ' . $listimport->id . '</td>
                                    <td><a href="' . MAINLINK . 'upload/collection_excel/' . $listimport->excel_filename . '" download>' . $listimport->excel_filename . '</a></td>
                                    <td>' . $listimport->created_on . '</td>
                                    <td>' . $getrowcount . '</td>
                                    <td><a href="viewcollectionrecords.php?id='.$listimport->id.'&lotno='.$lotno.'">View</a></td>
                                    <td><a class="deleteme" href="importdelete.php?cdid=' . $listimport->id . '">Delete</a></td>
                                </tr>';

                                $y++;

                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</div>
<!-- /.container-fluid -->

<?php include('footer.php'); ?>

<script type="text/javascript">
$('.deleteme').click(function(){
    return confirm("Are you sure you want to delete?");
  });
</script>
</body>

</html>