<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT s.*, st.id as statename, c.id as clientname, z.id as zoneid FROM `sales_import` as s LEFT JOin `state` as st on st.title = s.state LEFT JOIN `client` as c on c.cname = s.client LEFT JOIN `zone` as z on z.title = s.zone group by s.invoice_no order by s.invoice_no ASC");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $invoice_no = $listquery->invoice_no;
    $inv_date = $listquery->inv_date;
    $city = $listquery->city;
    $client = $listquery->client;
    $gr_no = $listquery->gr_no;
    $statename = $listquery->statename;
    $clientname = $listquery->clientname;
    $discount_1 = $listquery->discount_1;
    $discount_2 = $listquery->discount_2;
    $discount_3 = $listquery->discount_3;
    $commission = $listquery->commission;
    $abt = $listquery->amount_before_tax;
    $zoneid = $listquery->zoneid;
    $gr_no = $listquery->gr_no;

    mysqli_query($sql, "INSERT INTO `invoice` (`inv_date`, `invoice_no`, `city`, `state`, `client_id`, `discount_1`, `discount_2`, `discount_3`, `commission`, `amount`, `zone`, `gr_no`) VALUE ('$inv_date', '$invoice_no', '$city', '$statename', '$clientname', '$discount_1', '$discount_2', '$discount_3', '$commission', '$abt', '$zoneid', '$gr_no')");

    /*echo "INSERT INTO `invoice` (`inv_date`, `invoice_no`, `city`, `state`, `client_id`, `discount_1`, `discount_2`, `discount_3`, `commission`, `amount`, `zone`, `gr_no`) VALUE ('$inv_date', '$invoice_no', '$city', '$statename', '$clientname', '$discount_1', '$discount_2', '$discount_3', 0, '$zoneid', '$gr_no') <br>";*/

}

?>