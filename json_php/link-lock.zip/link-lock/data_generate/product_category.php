<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT p.id, s.product_group, s.product_category FROM `sales_import` as s 
LEFT JOIN product_group as p on p.title = s.product_group
group by s.product_category;");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $pcategory = $listquery->product_category;
    $pid = $listquery->id;

    mysqli_query($sql, "INSERT INTO `product_category` (`pgid`, `title`) VALUE ('$pid', '$pcategory')");

}

?>