<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `sales_import` group by `client`");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $client = $listquery->client;

    mysqli_query($sql, "INSERT INTO `client` (`cname`, `cdate`) VALUE ('$client', '$cdate')");

}

?>