<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT `id`, `Date` FROM `sales_import_1`");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $invdate = $listquery->Date;
    $id = $listquery->id;

    $year = substr($invdate,8);
    $day = substr($invdate,0,3);
    $m = substr($invdate,4,3);

    $month = array("Jan"=>"01", "Feb"=>"02", "Mar"=>"03", "Apr"=>"04", "May"=>"05", "Jun"=>"06", "Jul"=>"07", "Aug"=>"08", "Sep"=>"09", "Oct"=>"10", "Nov"=>"11", "Dec"=>"12");

    //echo $m;
    //echo '<br>';

    $monthnu = $month[$m];

    $invymd = $year.'-'.$monthnu.'-'.trim($day);

    //echo $invdate.' - '.$invymd.'<br>';

    mysqli_query($sql, "UPDATE `sales_import` SET `inv_date` = '$invymd' where `id` = '$id'");

}

?>