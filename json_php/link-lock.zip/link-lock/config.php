<?php
session_start();
//=====session name======
$session = 'linklock';

define('SESSION', 'linklock');
define('MAINLINK', 'https://project-uat.com/link-lock/');

//echo '<pre>' . print_r($_SESSION, TRUE) . '</pre>';

//===cashe clear code=====
header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

//==db connection===
require_once 'database/DB.class.php';

//define('SQL', $sql);

date_default_timezone_set('Asia/Kolkata');


// REQUIRED MAIL
include('Classes/class.phpmailer.php');
include('email/sendEmail.php');

$mainlink2 = "https://project-uat.com/link-lock/";

//=======smtpdetail=======================
$host="bipabioagri.in";
$port= 465;
$username="noreply@womenforagri.com";
$password= "NeWDhI0K~;Dd";
$from="abhishek@apachiweb.co.in";
$fromname="NBHM Exam";


?>