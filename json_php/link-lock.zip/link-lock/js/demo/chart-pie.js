// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';
Chart.defaults.global.defaultFontSize = 12;

const graph = document.getElementById("highpermorfingpie").getContext("2d");


Chart.defaults.global.defaultFontSize = 12;

let massPopChart = new Chart(graph, {
  type: "pie", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["Bengal - UP - Bihar | 16%", "Maharatsra | 13%", "Hariyana-Chandigadh | 13%", "North-East | 14%", "Andhra-MP-Tamilnadu | 13%", "Karnataka-Kerala | 15%", "Gujrat-Rajsthan | 16%",],

    datasets: [
      {
        label: "Population en M ",
        data: [220, 175, 174, 196, 184, 209, 220,],
        // backgroundColor: "blue",
        backgroundColor: [ "#7eb0d5", "#b2e061", "#bd7ebe", "#ffb55a", "#ffee65", "#beb9db", "#fdcce5",],
       
        hoverBorderWidth: 3
      }]
  },
  options: {
    title: {
      display: false,
      text: "High Performing Regions",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
});
//# High Graph Chart 

const graph2 = document.getElementById("highpermorfingproduct").getContext("2d");

Chart.defaults.global.defaultFontSize = 12;

let massPopChart2 = new Chart(graph2, {
  type: "pie", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["HI-TECH-S-67SS | 10%", "NEW ROUND BCP 65MM | 19%", "HI-TECH-60MM | 10%", "NEW ROUND BRASS 65MM | 15%", "HI-TECH-ROUND 65 | 14%", "HI-TECH-R-65SS | 13%", "NEW ROUND BCP 50 MM | 16%",],

    datasets: [
      {
        label: "Population en M ",
        data: [220, 175, 174, 196, 184, 209, 220,],
        // backgroundColor: "blue",
        backgroundColor: [ "#76c8c8", "#c80064", "#badbdb", "#dedad2", "#e4bcad", "#df979e", "#d7658b", ],
        hoverBorderWidth: 3
      }]
  },
  options: {
    title: {
      display: false,
      text: "High Performing Product",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
});

//#high perform product close


const graph3 = document.getElementById("highpermorfingcategory").getContext("2d");

Chart.defaults.global.defaultFontSize = 12;

let massPopChart3 = new Chart(graph3, {
  type: "pie", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["ATOOT-SS", "ATOOT", "HI-TECH", "NEW ROUND BCP", "NEW ROUND BRASS", ],

    datasets: [
      {
        label: "Population en M ",
        data: [93, 98, 86, 54, 57,],
        // backgroundColor: "blue",
        backgroundColor: [ "#54bebe",  "#d7658b", "#df979e", "#badbdb", "#dedad2",  ],
        hoverBorderWidth: 3
      }]
  },
  options: {
    title: {
      display: false,
      text: "High Performing Category",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
});

//high perform category piechart close



const graph4 = document.getElementById("lowpermorfingcategory").getContext("2d");

Chart.defaults.global.defaultFontSize = 12;

let massPopChart4 = new Chart(graph4, {
  type: "pie", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["ABC | 17%", "XYZ | 13%", "EFG | 32%", "RGF | 11%", "WWE | 31%", ],

    datasets: [
      {
        label: "Population en M ",
        data: [20, 15, 37, 12, 31,],
        // backgroundColor: "blue",
        backgroundColor: [ "#ffee65", "#beb9db", "#fd7f6f", "#7eb0d5", "#b2e061",],

        hoverBorderWidth: 3
      }]
  },
  options: {
    title: {
      display: false,
      text: "Low Performing Category",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
});



// Pie Chart Example
/*
var ctx = document.getElementById("high-permorfing-region-pie");
var myPieChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: ["Direct", "Referral", "Social"],
    datasets: [{
      data: [55, 30, 15],
      backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
      hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 80,
  },
});
*/


// Pie Chart Example
// var ctx2 = document.getElementById("myPieChart2");
// var myPieChart2 = new Chart(ctx2, {
//   type: 'pie',
//   data: {
//     labels: ["Direct", "Referral", "Social"],
//     datasets: [{
//       data: [55, 30, 15],
//       backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
//       hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
//       hoverBorderColor: "rgba(234, 236, 244, 1)",
//     }],
//   },
//   options: {
//     maintainAspectRatio: false,
//     tooltips: {
//       backgroundColor: "rgb(255,255,255)",
//       bodyFontColor: "#858796",
//       borderColor: '#dddfeb',
//       borderWidth: 1,
//       xPadding: 15,
//       yPadding: 15,
//       displayColors: false,
//       caretPadding: 10,
//     },
//     legend: {
//       display: false
//     },
//     cutoutPercentage: 80,
//   },
// });


// Pie Chart Example
/*var ctx3 = document.getElementById("myPieChart3");
var myPieChart3 = new Chart(ctx3, {
  type: 'pie',
  data: {
    labels: ["Direct", "Referral", "Social"],
    datasets: [{
      data: [55, 30, 15],
      backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
      hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 80,
  },
});*/


// Pie Chart Example
/*var ctx4 = document.getElementById("myPieChart4");
var myPieChart4 = new Chart(ctx4, {
  type: 'pie',
  data: {
    labels: ["Direct", "Referral", "Social"],
    datasets: [{
      data: [55, 30, 15],
      backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
      hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 80,
  },
});*/
