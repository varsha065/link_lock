<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `sales_import` group by `zone`");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $pgroup = $listquery->zone;

    mysqli_query($sql, "INSERT INTO `zone` (`title`, `cdate`) VALUE ('$pgroup', '$cdate')");

}

?>