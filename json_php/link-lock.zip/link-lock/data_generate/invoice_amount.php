<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `invoice`  where id > 8770 ");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $invoice_no = $listquery->invoice_no;
    $id = $listquery->id;
    
    $gettotal = mysqli_query($sql, "SELECT sum(amount_before_tax) as amount FROM `product_cart` where `invoice_no` = '$invoice_no'");
    $listtotal = mysqli_fetch_object($gettotal);

    $amount = $listtotal->amount;

    mysqli_query($sql, "UPDATE `invoice` SET `amount` = '$amount' where id  = '$id'"); 

}

?>