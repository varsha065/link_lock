<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `sales_import` group by `executive`");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $executive = $listquery->executive;

    mysqli_query($sql, "INSERT INTO `executive` (`ename`, `cdate`) VALUE ('$executive', '$cdate')");

}

?>