<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT z.id, s.zone, s.state FROM `sales_import` as s 
LEFT JOIN zone as z on z.title = s.zone
group by s.state");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $state = $listquery->state;
    $zid = $listquery->id;

    mysqli_query($sql, "INSERT INTO `state` (`zid`, `title`, `cdate`) VALUE ('$zid', '$state', '$cdate')");

}

?>