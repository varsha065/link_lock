// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';
Chart.defaults.global.defaultFontSize = 12;

const graph = document.getElementById("amount").getContext("2d");


Chart.defaults.global.defaultFontSize = 12;

let massPopChart = new Chart(graph, {
  type: "pie", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["Pad Lock | 16%", "Lock1 | 17% ", "Lock2 | 13%", "Lock3 | 10%", "Lock4 | 14%", "Lock5 | 13%", "Lock6 | 17%",],

    datasets: [
      {
        label: "Population en M ",
        data: [16, 17, 13, 10, 14, 13, 17,],
        // backgroundColor: "blue",
        backgroundColor: [ "#b2e061", "#bd7ebe", "#ffb55a", "#ffee65", "#beb9db", "#fdcce5", "#8bd3c7",],

        hoverBorderWidth: 3
      }]
  },
  options: {
    title: {
      display: false,
      text: "High Performing Regions",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
});

//zone resell
const graph2 = document.getElementById("zoneresellers").getContext("2d");


Chart.defaults.global.defaultFontSize = 12;

let massPopChart2 = new Chart(graph2, {
  type: "doughnut", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["East", "West ", "North", "South", ],
 
    datasets: [
      {
        label: "Population en M ",
        data: [1096, 1241, 3950, 4599, ],
        // backgroundColor: "blue",
        backgroundColor: ["#fd7f6f", "#7eb0d5", "#b2e061", "#bd7ebe", "#ffb55a", "purple", "green",],

        hoverBorderWidth: 3
      }]
  },

  options: {
    title: {
      display: false,
      text: "High Performing Regions",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
 
});