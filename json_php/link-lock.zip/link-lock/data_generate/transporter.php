<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `sales_import` group by `transport`");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $transport = $listquery->transport;

    mysqli_query($sql, "INSERT INTO `transport` (`tname`, `cdate`) VALUE ('$transport', '$cdate')");

}

?>