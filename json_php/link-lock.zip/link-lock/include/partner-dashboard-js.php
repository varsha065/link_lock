<script>
// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

const graph = document.getElementById("amount").getContext("2d");


Chart.defaults.global.defaultFontSize = 12;

function number_format(number, decimals, dec_point, thousands_sep) {
    // *     example: number_format(1234.56, 2, ',', ' ');
    // *     return: '1 234,56'
    number = (number + '').replace(',', '').replace(' ', '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function (n, prec) {
            var k = Math.pow(10, prec);
            return '' + Math.round(n * k) / k;
        };
    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}

const distributor = {
    labels: [<?php echo getclientbusiness_10name($sql, 'DESC'); ?>],
    datasets: [{
        type: 'bar',
        label: 'Sales',
        data: [<?php echo getclientbusiness_10biz($sql, 'DESC'); ?>],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart7");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: distributor,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
//active region

const activewisebar = {
    labels: [
        'S L Company',
        'K G Dass',
        'J Agency',
        'G Hardware',
        'F Enterprises',
        'ABC',
        'XYZ'
    ],
    datasets: [{
        type: 'bar',
        label: 'Unit Sold',
        data: [255, 205, 303, 408, 286, 213, 325],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Sales',
        data: [125, 183, 234, 309, 169, 214, 289],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart8");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: activewisebar,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
//active region bar


const activewiseline = {
    labels: [<?php echo getclientbusiness_10name($sql, 'DESC'); ?>],
    datasets: [{
        type: 'line',
        label: 'Unit Sold',
        data: [255, 205, 303, 408, 286, 213, 325, 286, 213, 325],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Sales',
        data: [125, 183, 234, 309, 169, 214, 289, 286, 213, 325],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart9");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: activewiseline,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});



//#main page bars

let massPopChart = new Chart(graph, {
  type: "pie", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["East", "West", "North", "South", "Export"],

    datasets: [
      {
        label: "Population en M ",
        data: [<?php echo zone_outstanding($sql, 'East'); ?>, <?php echo zone_outstanding($sql, 'West'); ?>, <?php echo zone_outstanding($sql, 'North'); ?>, <?php echo zone_outstanding($sql, 'South'); ?>, <?php echo zone_outstanding($sql, 'EXP'); ?>],
        // backgroundColor: "blue",
        backgroundColor: [ "#b2e061", "#bd7ebe", "#ffb55a", "#ffee65", "#beb9db", "#fdcce5", "#8bd3c7",],

        hoverBorderWidth: 3
      }]
  },
  options: {
    title: {
      display: false,
      text: "High Performing Regions",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
});

//zone resell
const graph2 = document.getElementById("zoneresellers").getContext("2d");


Chart.defaults.global.defaultFontSize = 12;

let massPopChart2 = new Chart(graph2, {
  type: "doughnut", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
  data: {
    labels: ["East", "West ", "North", "South", ],
 
    datasets: [
      {
        label: "Population en M ",
        data: [<?php echo zone_count($sql, 1) ?>, <?php echo zone_count($sql, 5) ?>, <?php echo zone_count($sql, 3) ?>, <?php echo zone_count($sql, 4) ?>, ],
        // backgroundColor: "blue",
        backgroundColor: ["#fd7f6f", "#7eb0d5", "#b2e061", "#bd7ebe"],

        hoverBorderWidth: 3
      }]
  },

  options: {
    title: {
      display: false,
      text: "High Performing Regions",
      fontSize: 12
    },
    legend: {
      display: false
    },
    // start at 0
    scales: {
      yAxes: [
        {
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero: false,
            display: false
          }
        }]
    },

  }
 
});








</script>