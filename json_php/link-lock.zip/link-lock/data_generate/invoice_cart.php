<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT s.invoice_no, p.id, p.pcid, p.pgid, s.quantity, s.rate, s.amount_before_tax  FROM `sales_import` as s LEFT JOIN `product` as p on p.title = s.product ");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $invoice_no = $listquery->invoice_no;
    $pid = $listquery->id;
    $pcid = $listquery->pcid;
    $pgid = $listquery->pgid;
    $quantity = $listquery->quantity;
    $amount_before_tax = $listquery->amount_before_tax;
    $rate = $listquery->rate;

    mysqli_query($sql, "INSERT INTO `product_cart` (`invoice_no`, `pid`, `pcid`, `pgid`, `quantity`, `rate`, `amount_before_tax`) VALUE ('$invoice_no', '$pid', '$pcid', '$pgid', '$quantity', '$rate', '$amount_before_tax')"); 

}

?>