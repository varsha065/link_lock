<?php
$pagname = 'show';
include('config.php');
include('header.php');
include('partner-graphvalue.php');
?>


    <style>
        .progress {
            display: flex;
            height: 1rem;
            overflow: hidden;
            line-height: 0;
            font-size: 0.75rem;
            background-color: #3d8949;
            border-radius: 2px;
            
        }
        .progress-bar {
  display: flex;
  flex-direction: column;
  justify-content: center;
  overflow: hidden;
  color: #fff;
  text-align: center;
  white-space: nowrap;
  background-color: darkcyan !important;
  transition: width 0.6s ease;
}

        table td {
            font-size: 12px;
            font-weight: 700;
            color: black;
            background: beige;
        }
        .colwidth{
            width:50%;
        }
        @media only screen and (max-width: 576px) {
  .mobileheight1 {
    height: 380px !important;
  }
}

@media only screen and (min-width: 577px) and (max-width: 992px) {
  .mobileheight1 {
    height: 660px !important;
  }
}
        @media only screen and (min-width: 993px)  {
        .mobileheight1 {
         height: 415px !important;  
        } 
}
    </style>
<script type="text/javascript">
    $('#filter').hide();
</script>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Partner Dashboard</h1>

    <div class="row">
        <div class="col-xl-8 col-md-8 col-lg-8">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex " style="justify-content:space-between">
                    <h6 class="m-0 font-weight-bold text-primary">Top 10 Distributor Sale </h6>
                    <i type="button" class="fa fa-ellipsis-v" data-container="body" data-toggle="popover" data-placement="bottom" data-content="Filter"></i>
                </div>
                <div class="card-body mobileheight" >
                    <div class="chart-bar" >
                        <canvas id="myBarChart7"></canvas>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-xl-4 col-md-4 col-lg-4">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex" style="justify-content:space-between" >
                    <h6 class="m-0 font-weight-bold text-primary">Zone Wise - O/S Amount</h6>
                    <i type="button" class="fa fa-ellipsis-v" data-container="body" data-toggle="popover" data-placement="bottom" data-content="Filter"></i>
                </div>
                <div class="card-body mobileheight1" >
                    <div class="chart-bar text-center" >
                        <canvas id="amount" height="300"></canvas>
                        <div class="card-body mobileheight">
                              <div id="highpermorfingpie-data2" class="sale-status-legends sales-location"
                                    style="display:none;">
                                    <ul class="text-left">
                                        <li class="label-secondary row">

                                            <div class="legend-label col-6 pad-l-0 "><strong>Region</strong></div>
                                            <div class="legend-data col-6"><strong>O/S Amount</strong></div>
                                            
                                        </li>
                                        <li class="label-secondary row alt">

                                            <div class="legend-label col-6 pad-l-0">North</div>
                                            <div class="legend-data col-6">16995718</div>
                                    
                                        </li>
                                        <li class="label-secondary row ">
                                            <div class="legend-label col-6 pad-l-0">South</div>
                                            <div class="legend-data col-6">15827292</div>
                                            
                                        </li>
                                        <li class="label-secondary row alt">
                                            <div class="legend-label col-6 pad-l-0">East</div>
                                            <div class="legend-data col-6">52721388</div>
                                        
                                        </li>
                                    
                                        <li class="label-secondary row">
                                            <div class="legend-label col-6 pad-l-0">West</div>
                                            <div class="legend-data col-6">3530234</div>
                                        
                                        </li>
                                        <li class="label-secondary row alt">
                                            <div class="legend-label col-6 pad-l-0">Export</div>
                                            <div class="legend-data col-6">8894212</div>
                                        
                                        </li>
                                    
                                    </ul>

                                </div>
                                <button class="btn-sm btn-primary mt-3 " id="osamount" style="outline:none"> View
                                    Data</button>
                 
                         </div>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <div class="row">
        <div class="col-xl-4 col-md-4  col-lg-4">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Total O/S: <?php echo total_outstanding($sql); ?></h6>
                </div>
                <div class="card-body mobileheight">
                    <div class="chart-bar">
                        <div id="amount-data" class="sale-status-legends sales-location">
                            <ul class="text-left">
                                <li class="label-secondary row">

                                    <div class="legend-label col-7 pad-l-0 text-left"><strong>Outstanding Period</strong></div>
                                    <div class="legend-data col-5 text-left"><strong>Amount</strong></div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">0 To 45 days</div>
                                    <div class="legend-data col-5"><?php echo zoneoutstanding_ageall($sql, 1); ?></div>
                                </li>
                                <li class="label-secondary row ">

                                    <div class="legend-label col-7 pad-l-0">46 To 90 days</div>
                                    <div class="legend-data col-5"><?php echo zoneoutstanding_ageall($sql, 2); ?></div>
                                </li>
                                <li class="label-secondary row alt">

                                    <div class="legend-label col-7 pad-l-0">91 To 180 days</div>
                                    <div class="legend-data col-5"><?php echo zoneoutstanding_ageall($sql, 3); ?></div>
                                </li>
                                <li class="label-secondary row ">

                                    <div class="legend-label col-7 pad-l-0">More than 180 days</div>
                                    <div class="legend-data col-5"><?php echo zoneoutstanding_ageall($sql, 4); ?></div>
                                </li>

                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-4 col-lg-4">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Age wise outstanding in regions</h6>
                </div>
                <div class="card-body mobileheight">
                    <div class="chart-bar">
                        <div id="highpermorfingpie-data" class="sale-status-legends sales-location">
                            <ul class="text-center">
                                <li class="label-secondary row">

                                    <div class="legend-label col-3 pad-l-0 text-left"><strong>Region Wise</strong></div>
                                    <div class="legend-data col-3 text-left"><strong>0 to 90</strong></div>
                                    <div class="legend-data col-3 text-left"><strong>91 to 180</strong></div>
                                    <div class="legend-data col-3 text-left"><strong>> 180</strong></div>
                                </li>
                                <li class="label-secondary row alt">

                                    <div class="legend-label col-3 pad-l-0">East</div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'East', 1); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'East', 2); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'East', 3); ?></div>
                                </li>
                                <li class="label-secondary row ">

                                    <div class="legend-label col-3 pad-l-0">West</div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'West', 1); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'West', 2); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'West', 3); ?></div>
                                </li>
                                <li class="label-secondary row alt">

                                    <div class="legend-label col-3 pad-l-0">North</div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'North', 1); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'North', 2); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'North', 3); ?></div>
                                </li>
                                <li class="label-secondary row ">

                                    <div class="legend-label col-3 pad-l-0">South</div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'South', 1); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'South', 2); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'South', 3); ?></div>
                                </li>
                                <li class="label-secondary row ">

                                    <div class="legend-label col-3 pad-l-0">Export</div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'EXP', 1); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'EXP', 2); ?></div>
                                    <div class="legend-data col-3"><?php echo zoneoutstanding_age($sql, 'EXP', 3); ?></div>
                                </li>

                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-4 col-lg-4">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex" style="justify-content:space-between">
                    <h6 class="m-0 font-weight-bold text-primary"> Zone Wise Active ReSellers</h6>
                    
                    <!-- <a href="#" data-toggle="popover" data-placement="bottom" title="Popover Header" data-content="Some content inside the popover"><i type="button" class="fa fa-ellipsis-v" id="resellerfilter" aria-hidden="true"></i></a> -->
                    <i type="button" class="fa fa-ellipsis-v" data-container="body" data-toggle="popover" data-placement="bottom" data-content="Vivamus
                          sagittis lacus vel augue laoreet rutrum faucibus."></i>
                    
                </div>
                <div id="resellerfilter1" class="d-none"> hii</div>
                <div class="card-body mobileheight">
                    <div class="chart-bar text-center">
                        <canvas id="zoneresellers" height="300 !important"></canvas>
                        
                        <div id="highpermorfingpie-data1" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul class="text-left">
                                <li class="label-secondary row">

                                    <div class="legend-label col-6 pad-l-0 "><strong>Region</strong></div>
                                    <div class="legend-data col-6"><strong>Resellers</strong></div>
                                    
                                </li>
                                <li class="label-secondary row alt">

                                    <div class="legend-label col-6 pad-l-0">North</div>
                                    <div class="legend-data col-6">1033</div>
                               
                                </li>
                                <li class="label-secondary row ">
                                    <div class="legend-label col-6 pad-l-0">South</div>
                                    <div class="legend-data col-6">129</div>
                                    
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-6 pad-l-0">East</div>
                                    <div class="legend-data col-6">221</div>
                                    <!-- <div class="legend-data col-3">13%</div> -->
                                </li>
                            
                                <li class="label-secondary row">
                                    <div class="legend-label col-6 pad-l-0">West</div>
                                    <div class="legend-data col-6">385</div>
                                 
                                </li>
                              
                            </ul>

                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="zonewise" style="outline:none"> View
                            Data</button>
                    </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <div class="row" style="display:none;">
        <div class="col-xl-12 col-md-12 col-lg-12">

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Top 10 Low Performer</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table width="100%">
                            <tr>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width:15%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">15%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 25%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 32%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">32%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">LSKNVLSK</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 32%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">32%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 45%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">45%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 20%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">20%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">IJDBCKLSJN</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 35%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">35%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">50%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 78%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">78%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    <table border="1" padding="3px" width="100%" class="low">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="text-center">KSKDH DFIODFV</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="colwidth">FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>FY 2020-2021</td>
                                                <td>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: 50%;"
                                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-xl-12 col-md-12 col-lg-12">

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Top Performer Sales Product Mix</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table width="100%">
                            <tr>
                                <?php getclientbusiness($sql, 'DESC'); ?>
                            </tr>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="row" style="display:none;">


        <div class="col-xl-6 col-md-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Region Wise Active ReSellers</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart8"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-md-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Region Wise Active ReSellers </h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart9"></canvas>
                    </div>
                </div>
            </div>
        </div>



    </div>


</div>
<!-- /.container-fluid -->

<?php include('footer.php'); ?>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>
<?php include('include/partner-dashboard-js.php'); ?>
<script src="js/function.js"></script>

<script id="rendered-js">

</script>
<script>
    $(document).ready(function () {

        $('#zonewise').click(function () {

            $('#zoneresellers').toggle();
            $('#highpermorfingpie-data1').toggle();

            // $(this).text('View Chart');
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });

        $('#osamount').click(function () {

            $('#amount').toggle();
            $('#highpermorfingpie-data2').toggle();
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        }); 

        $('#resellerfilter').click(function () {

           $('#zonefilter').toggle();
        //    $('#highpermorfingpie-data2').toggle();
        //    $(this).text(function (i, text) {
        //       return text === "View Chart" ? "View Data" : "View Chart";
        //     })
        });
    
        // $('#resellerfilter').click(function () {
        //     $('#resellerfilter1').popover('show');
        // });
        
        $('[data-toggle="popover"]').popover(); 

    });
    
</script>




</body>

</html>