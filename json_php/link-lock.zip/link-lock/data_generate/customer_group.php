<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `sales_import` group by `customer_group`");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $cgroup = $listquery->customer_group;

    mysqli_query($sql, "INSERT INTO `customer_group` (`title`, `cdate`) VALUE ('$cgroup', '$cdate')");

}

?>