// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

function number_format(number, decimals, dec_point, thousands_sep) {
    // *     example: number_format(1234.56, 2, ',', ' ');
    // *     return: '1 234,56'
    number = (number + '').replace(',', '').replace(' ', '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function (n, prec) {
            var k = Math.pow(10, prec);
            return '' + Math.round(n * k) / k;
        };
    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}


// const distributor = {
//     labels: [
//         'Sankar Light Company',
//         'KhushiRam Ghurmukh Dass',
//         'Jindal Agency',
//         'Genuine Hardware',
//         'Faraz Enterprises',
//         'ABC',
//         'XYZ'
//     ],
//     datasets: [{
//         type: 'bar',
//         label: 'Unit Sold',
//         data: [25532462, 20586314, 30365412, 40865324, 28658452, 21365425, 32563248],
//         borderColor: 'rgb(255, 99, 132)',
//         backgroundColor: 'rgba(255, 99, 132, 0.2)'
//     }, {
//         type: 'line',
//         label: 'Sales',
//         data: [12536248, 18365874, 23456218, 30986525, 16987457, 21475632, 28965875],
//         fill: false,
//         borderColor: 'rgb(54, 162, 235)'
//     }],

// };


// // Bar Chart Example
// var ctx3 = document.getElementById("myBarChart7");
// var myBarChart3 = new Chart(ctx3, {
//     type: 'bar',
//     data: distributor,
//     options: {
//         scales: {
//             y: {
//                 beginAtZero: true
//             }
//         }
//     }
// });


const distributor = {
    labels: [
        'S L Company',
        'K G Dass',
        'J Agency',
        'G Hardware',
        'F Enterprises',
        'ABC',
        'XYZ'
    ],
    datasets: [{
        type: 'bar',
        label: 'Unit Sold',
        data: [255, 205, 303, 408, 286, 213, 325],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Sales',
        data: [125, 183, 234, 309, 169, 214, 289],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart7");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: distributor,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
//active region
/*const activewisebar = {
    labels: [
        'Sankar Light Company',
        'KhushiRam Ghurmukh Dass',
        'Jindal Agency',
        'Genuine Hardware',
        'Faraz Enterprises',
        'ABC',
        'XYZ'
    ],
    datasets: [{
        type: 'bar',
        label: 'Unit Sold',
        data: [25532462, 20586314, 30365412, 40865324, 28658452, 21365425, 32563248],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Sales',
        data: [12536248, 18365874, 23456218, 30986525, 16987457, 21475632, 28965875],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart8");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: activewisebar,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});*/

const activewisebar = {
    labels: [
        'S L Company',
        'K G Dass',
        'J Agency',
        'G Hardware',
        'F Enterprises',
        'ABC',
        'XYZ'
    ],
    datasets: [{
        type: 'bar',
        label: 'Unit Sold',
        data: [255, 205, 303, 408, 286, 213, 325],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Sales',
        data: [125, 183, 234, 309, 169, 214, 289],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart8");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: activewisebar,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
//active region bar
/*const activewiseline = {
    labels: [
        'Sankar Light Company',
        'KhushiRam Ghurmukh Dass',
        'Jindal Agency',
        'Genuine Hardware',
        'Faraz Enterprises',
        'ABC',
        'XYZ'
    ],
    datasets: [{
        type: 'line',
        label: 'Unit Sold',
        data: [25532462, 20586314, 30365412, 40865324, 28658452, 21365425, 32563248],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Sales',
        data: [12536248, 18365874, 23456218, 30986525, 16987457, 21475632, 28965875],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart9");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: activewiseline,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});*/

const activewiseline = {
    labels: [
        'S L Company',
        'K G Dass',
        'J Agency',
        'G Hardware',
        'F Enterprises',
        'ABC',
        'XYZ'
    ],
    datasets: [{
        type: 'line',
        label: 'Unit Sold',
        data: [255, 205, 303, 408, 286, 213, 325],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Sales',
        data: [125, 183, 234, 309, 169, 214, 289],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }],

};


// Bar Chart Example
var ctx3 = document.getElementById("myBarChart9");
var myBarChart3 = new Chart(ctx3, {
    type: 'bar',
    data: activewiseline,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});



//#main page bars








