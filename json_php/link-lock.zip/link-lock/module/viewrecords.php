<?php

function paging($sql, $start, $limit, $query) {

    $getdistributor = mysqli_query($sql, $query);

    $getcount = mysqli_num_rows($getdistributor);

    $dividnum = $getcount / $limit;
    $ceilval = floor($dividnum);

    $first = $start + 1;
    $second = $start + 2; 
    $third = $start + 3;

    $flast = $ceilval - 3;
    $tlast = $ceilval - 2;
    $slast = $ceilval - 1;

    if($first > $flast) {
        $start = 0;
        $first = 1;
        $second = 2; 
        $third = 3;
    }

    echo '<nav aria-label="Page navigation example">
            <ul class="pagination justify-content-end">
                <li class="page-item">
                    <a class="page-link" href="?start=0">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>';

                if($ceilval > 7) {

                    echo '<li class="page-item"><a class="page-link" href="?start='.$start.'">'.$first.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$first.'">'.$second.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$second.'">'.$third.'</a></li>
                    <li class="page-item"><a class="page-link" href="">...</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$tlast.'">'.$tlast.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$slast.'">'.$slast.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$ceilval.'">'.$ceilval.'</a></li>';

                } else {
                    for($x = $start; $x <= $ceilval; $x++){

                        $display = $x + 1;
    
                        echo '<li class="page-item"><a class="page-link" href="?start='.$x.'">'.$display.'</a></li>';
                    }
                }


        echo '<li class="page-item">
                <a class="page-link" href="?start='.$ceilval.'">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>';


}   





?>

