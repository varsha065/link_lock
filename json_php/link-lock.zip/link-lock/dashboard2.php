<?php
include('config.php');
include('header.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Sales Dashboard</h1>

    <div class="row">
        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Total Sale YTD : 35,07,98,729</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Total Sale QTD : 35,07,98,729</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart2"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Category Wise Total Sale</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart3"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xl-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Target Vs Achived</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart4"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Regions</h6>
                </div>
                <div class="card-body mobileheight">
                    <div class="chart-bar text-center">
                        <canvas id="highpermorfingpie" height="300"></canvas>

                        <div id="highpermorfingpie-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul>
                                <li class="label-secondary row">

                                    <div class="legend-label col-6 pad-l-0"><strong>Region</strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                </li>
                                <li class="label-secondary row alt">

                                    <div class="legend-label col-6 ">Bengal - UP - Bihar</div>
                                    <div class="legend-data col-3">220</div>
                                    <div class="legend-data col-3">16%</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-6 pad-l-0">Maharatsra</div>
                                    <div class="legend-data col-3">175</div>
                                    <div class="legend-data col-3">13%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-6 pad-l-0">Hariyana-Chandigadh</div>
                                    <div class="legend-data col-3">174</div>
                                    <div class="legend-data col-3">13%</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-6 pad-l-0">North-East</div>
                                    <div class="legend-data col-3">196</div>
                                    <div class="legend-data col-3">14%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-6 pad-l-0">Andhra-MP-Tamilnadu</div>
                                    <div class="legend-data col-3">184</div>
                                    <div class="legend-data col-3">13%</div>
                                </li>
                                <li class="label-secondary row ">
                                    <div class="legend-label col-6 pad-l-0">Karnataka-Kerala</div>
                                    <div class="legend-data col-3">209</div>
                                    <div class="legend-data col-3">15%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-6 pad-l-0">Gujrat-Rajsthan</div>
                                    <div class="legend-data col-3">220</div>
                                    <div class="legend-data col-3">16%</div>
                                </li>
                            </ul>

                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="highregion" style="outline:none"> view
                            Data</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Product</h6>
                </div>
                <div class="card-body mobileheight">
                    <div class="chart-bar text-center">
                        <canvas id="highpermorfingproduct" height="300"></canvas>

                        <div id="highpermorfingproduct-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-6 pad-l-0"><strong>Region</strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-9 pad-l-0">HI-TECH-S-67SS</div>
                                    <div class="legend-data col-3">10%</div>

                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-9">NEW ROUND BCP 65MM</div>

                                    <div class="legend-data col-3">16%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-9 pad-l-0">HI-TECH-60MM</div>
                                    <div class="legend-data col-3">10%</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-9">NEW ROUND BRASS 65MM</div>
                                    <div class="legend-data col-3">18%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-9 pad-l-0">HI-TECH-ROUND 65</div>
                                    <div class="legend-data col-3">14%</div>
                                </li>
                                <li class="label-secondary row ">
                                    <div class="legend-label col-9 pad-l-0">HI-TECH-R-65SS</div>
                                    <div class="legend-data col-3">13%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-9">NEW ROUND BCP 50 MM</div>
                                    <div class="legend-data col-3">19%</div>
                                </li>
                            </ul>

                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="highproduct" style="outline:none"> view
                            Data</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Category</h6>
                </div>
                <div class="card-body text-center mobileheight">
                    <div class="chart-bar">
                        <canvas id="highpermorfingcategory" height="300"></canvas>

                        <div id="highpermorfingcategory-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-6 pad-l-0"><strong>Region</strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-9 pad-l-0">ATOOT-SS</div>
                                    <div class="legend-data col-3">93</div>

                                </li>
                                <li class="label-secondary row ">
                                    <div class="legend-label col-9 pad-l-0">ATOOT</div>
                                    <div class="legend-data col-3">98</div>

                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-9">HI-TECH</div>

                                    <div class="legend-data col-3">86</div>
                                </li>
                                <li class="label-secondary row ">
                                    <div class="legend-label col-9 pad-l-0">NEW ROUND BCP</div>
                                    <div class="legend-data col-3">54</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-9">NEW ROUND BRASS</div>
                                    <div class="legend-data col-3">57</div>
                                </li>

                            </ul>

                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="highpercat" style="outline:none"> view
                            Data</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Low Performing Categories</h6>
                </div>
                <div class="card-body text-center mobileheight">
                    <div class="chart-bar">
                        <canvas id="lowpermorfingcategory" height="300px"></canvas>


                        <div id="lowpermorfingcategory-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-6 pad-l-0"><strong>Region</strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                    <div class="legend-data col-3"><strong></strong></div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-6 pad-l-0">ABC</div>
                                    <div class="legend-data col-3">20</div>
                                    <div class="legend-data col-3">17%</div>

                                </li>
                                <li class="label-secondary row ">
                                    <div class="legend-label col-6 pad-l-0">XYZ</div>
                                    <div class="legend-data col-3">15</div>
                                    <div class="legend-data col-3">13%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-6 pad-l-0">EFG</div>
                                    <div class="legend-data col-3">37</div>
                                    <div class="legend-data col-3">32%</div>
                                </li>
                                <li class="label-secondary row ">
                                    <div class="legend-label col-6 pad-l-0">RGF</div>
                                    <div class="legend-data col-3">12</div>
                                    <div class="legend-data col-3">11%</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-6 pad-l-0">WWE</div>
                                    <div class="legend-data col-3">31</div>
                                    <div class="legend-data col-3">27%</div>
                                </li>

                            </ul>
                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="lowperformcat" style="outline:none"> view
                            Data</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"> Month on Month Sales Performance %
                    </h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart5"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Partners</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Sansar Light Company</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Khushi Ram Gurum...</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Jindal Agency</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Genuine Hardware</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Faraz Enterprises</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Sansar Light Company</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Khushi Ram Gurum...</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Jindal Agency</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Genuine Hardware</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Faraz Enterprises</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Low Performing Partners</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>

                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Jindal Agency</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Genuine Hardware</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Faraz Enterprises</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Sansar Light Company</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Khushi Ram Gurum...</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Jindal Agency</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Genuine Hardware</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Faraz Enterprises</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Sansar Light Company</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Khushi Ram Gurum...</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Sales Executives</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Amar Singh</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Rakesh More</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Soham Jindal</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Ronit Shigvan</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Faraz Sheikh</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Jayant Sansar</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Ram Charan</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Jayesh Pai</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Sagar Khot</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Sunit Thakur</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Low Performing Sales Executives</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Jayant Sansar</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Ram Charan</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Jayesh Pai</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Sagar Khot</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Sunit Thakur</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Amar Singh</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Rakesh More</div>
                                    <div class="legend-data col-5">19,42,62,465</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Soham Jindal</div>
                                    <div class="legend-data col-5">19,46,59,074</div>
                                </li>
                                <li class="label-secondary row alt">
                                    <div class="legend-label col-7 pad-l-0">Ronit Shigvan</div>
                                    <div class="legend-data col-5">18,22,71,499</div>
                                </li>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0">Faraz Sheikh</div>
                                    <div class="legend-data col-5">17,55,86,724</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>

</div>
<!-- /.container-fluid -->

<?php include('footer.php'); ?>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>
<script src="js/demo/chart-bar.js"></script>
<script src="js/demo/chart-pie.js"></script>
<script src="js/function.js"></script>

<script id="rendered-js">

</script>
<script>
    $(document).ready(function () {

        $('#highregion').click(function () {

            $('#highpermorfingpie').toggle();
            $('#highpermorfingpie-data').toggle();

            // $(this).text('View Chart');
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });

        $('#highproduct').click(function () {

            $('#highpermorfingproduct').toggle();
            $('#highpermorfingproduct-data').toggle();
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });


        $('#highpercat').click(function () {

            $('#highpermorfingcategory').toggle();
            $('#highpermorfingcategory-data').toggle();
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });

        $('#lowperformcat').click(function () {

            $('#lowpermorfingcategory').toggle();
            $('#lowpermorfingcategory-data').toggle();

            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });


    });
</script>




</body>

</html>