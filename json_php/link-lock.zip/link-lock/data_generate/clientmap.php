<?php

include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `invoice` where `client_id` = 0");

    //$businsess = mysqli_query($sql, $query);

    while($listbuss = mysqli_fetch_object($query)) {

        $invoicno = $listbuss->invoice_no;
        $iid = $listbuss->id;

        $getinfo = mysqli_query($sql, "SELECT * FROM `sales_import` where `invoice_no` = '$invoicno'");

        $listinfo = mysqli_fetch_object($getinfo);

        $clientname = $listinfo->client;

        $getclient = mysqli_query($sql, "SELECT * FROM `client` where `cname` = '$clientname'");

        $getclinfo = mysqli_fetch_object($getclient);

        echo $invoicno.' - '.$listinfo->client.' - '.$getclinfo->id.'<br>';
        $cid = $getclinfo->id;

        mysqli_query($sql, "UPDATE `invoice` SET `client_id` = '$cid' where `id` = '$iid'");

    }
?>