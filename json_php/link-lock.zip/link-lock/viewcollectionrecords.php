<?php
include('config.php');
include('header.php');
//include('module/viewrecords.php');
if(isset($_GET['lotno'])){
    $newlotno = $_GET['lotno'];
}

$start = 0;
$pstart = 1;
$limit = 100;
$nxtstart = 0;

$query = "SELECT * FROM `collection_import` where `lot` = '$newlotno'";

if(isset($_GET['start'])) {
    $pstart = mysqli_real_escape_string($sql, $_GET['start']);
    $nxtstart = ($limit * $pstart) + 1;
    $start = $pstart;
}

function paging($sql, $start, $limit, $query, $newlotno) {

    $getdistributor = mysqli_query($sql, $query);

    $getcount = mysqli_num_rows($getdistributor);

    $dividnum = $getcount / $limit;
    $ceilval = floor($dividnum);

    $first = $start + 1;
    $second = $start + 2; 
    $third = $start + 3;

    $flast = $ceilval - 3;
    $tlast = $ceilval - 2;
    $slast = $ceilval - 1;

    if($first > $flast) {
        $start = 0;
        $first = 1;
        $second = 2; 
        $third = 3;
    }

    echo '<nav aria-label="Page navigation example">
            <ul class="pagination justify-content-end">
                <li class="page-item">
                    <a class="page-link" href="?start=0&lotno='.$newlotno.'">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>';

                if($ceilval > 7) {

                    echo '<li class="page-item"><a class="page-link" href="?start='.$start.'&lotno='.$newlotno.'">'.$first.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$first.'&lotno='.$newlotno.'">'.$second.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$second.'&lotno='.$newlotno.'">'.$third.'</a></li>
                    <li class="page-item"><a class="page-link" href="lotno='.$newlotno.'">...</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$tlast.'&lotno='.$newlotno.'">'.$tlast.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$slast.'&lotno='.$newlotno.'">'.$slast.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$ceilval.'&lotno='.$newlotno.'">'.$ceilval.'</a></li>';

                } else {
                    for($x = $start; $x <= $ceilval; $x++){

                        $display = $x + 1;
    
                        echo '<li class="page-item"><a class="page-link" href="?start='.$x.'&lotno='.$newlotno.'">'.$display.'</a></li>';
                    }
                }


        echo '<li class="page-item">
                <a class="page-link" href="?start='.$ceilval.'&lotno='.$newlotno.'">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>';


}
?>
<style type="text/css">
  body, html {
    margin: 0;
    padding: 0;
    height: 100%;
  } 
  .scroller {
    overflow: scroll;
    padding: 5px;
    height: 100%;
  }
</style>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Collection Excel Records : Lot No. - <?php echo $newlotno; ?></h1>

    

    <div class="row">

        <div class="col-xl-12 col-lg-12">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Collection List of Excel</h6>
                </div>
                <div class="card-body scroller">
                <table class="table ">
                    <thead class="thead-dark">
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Zone</th>
                        <th scope="col">State</th>
                        <th scope="col">City</th>
                        <th scope="col">Account Name</th>
                        <th scope="col">From Zero</th>
                        <th scope="col">From Four Six</th>
                        <th scope="col">From Six One</th>
                        <th scope="col">From Nine One</th>
                        <th scope="col">From Twelve One</th>
                        <th scope="col">From Fifteen One</th>
                        <th scope="col">Greaterthan Eighteen Zero</th>
                        <th scope="col">Total Outstanding</th>
                        <th scope="col">Credit Period</th>
                        <th scope="col">Outstanding Due</th>
                        <th scope="col">Received During</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $lotquery = mysqli_query($sql, "SELECT * FROM `collection_import` where `lot` = '$newlotno' LIMIT $nxtstart, $limit");

                            if($nxtstart == 0) {
                                $x = 1;
                            } else {
                                $x = $nxtstart; 
                            }

                            while($listimport = mysqli_fetch_object($lotquery)) {

                                $invoicedate = date('d-m-Y', strtotime($listimport->inv_date));

                                echo '<tr>
                                    <th scope="row">'.$x.'</th>
                                    <td>'.$listimport->zone.'</td>
                                    <td>'.$listimport->state.'</td>
                                    <td>'.$listimport->city.'</td>
                                    <td>'.$listimport->account_name.'</td>
                                    <td>'.$listimport->from_zero.'</td>
                                    <td>'.$listimport->from_four_six.'</td>
                                    <td>'.$listimport->from_six_one.'</td>
                                    <td>'.$listimport->from_nine_one.'</td>
                                    <td>'.$listimport->from_twelve_one.'</td>
                                    <td>'.$listimport->from_fifteen_one.'</td>
                                    <td>'.$listimport->greaterthan_eighteen_zero.'</td>
                                    <td>'.$listimport->total_outstanding.'</td>
                                    <td>'.$listimport->credit_period.'</td>
                                    <td>'.$listimport->outstanding_due.'</td>
                                    <td>'.$listimport->received_during.'</td>
                                </tr>';

                                $x++;

                            }
                        ?>
                    </tbody>
                    </table>
                    <?php paging($sql, $start, $limit, $query, $newlotno); ?>
                </div>
            </div>
        </div>

    </div>

</div>
<!-- /.container-fluid -->

<?php include('footer.php'); ?>


</body>

</html>