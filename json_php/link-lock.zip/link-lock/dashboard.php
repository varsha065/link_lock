<?php
$pagname = 'show';
include('config.php');
include('header.php');
include('graphvalue.php');
$fy = '';

if(isset($_GET['year'])) {
    $fyyear = $_GET['year'];
} else {
    $fyyear = "2022-23";
}

$fy_info = mysqli_query($sql, "SELECT * FROM `fy_year` where `fy_year` = '$fyyear'"); 
$get_fy_info = mysqli_fetch_object($fy_info);

$fy_start = $get_fy_info->start_month;
$fy_last = $get_fy_info->last_month;
?>

<style>
    .fy_box{
  position: absolute;
  top: -7px;
  font-size: 11px;
  background: #fff;
  left: 20px;
  padding: 0 6px;
  border-radius: 5px;
}
</style>

<script type="text/javascript">

    $(document).ready(function(){

        $('#filter').hide();

        $('#fy_year').change(function(){
            var getvalu = $(this).val();
            window.location.href = "?year="+getvalu;
        });

    });

    

</script>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row">
        <div class="col-md-5">
            <h1 class="h3 mb-4 text-gray-800">Sales Dashboard</h1>
        </div>
        <div class="col-md-7">
            <div class="row">
                <div class="col-2" style="position:relative;">
                    <p class="fy_box">Financial Year</p>
                    <select name="fy_year" id="fy_year" class="form-control" style="padding-top:12px;">
                        <option value="">Select Financial Year</option>
                        <?php fy_year($sql, 1); ?>
                    </select>
                </div>
            </div>
                
        </div>
        
    </div>

    <?php 
       /*ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);*/
    ?>

    <div class="row">
        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Total Sale YTD : <?php echo zonefull($sql, $fy_start, $fy_last); ?></h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Total Sale QTD : <?php echo zonefull_qtr($sql, '2022-10-01 00:00:00', '2023-12-31 23:59:00'); ?></h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart2"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Category Wise Total Sale</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart3"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xl-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Target Vs Achived</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart4"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Regions</h6>
                    <i type="button" class="fa fa-ellipsis-v" data-container="body" data-toggle="popover" data-placement="bottom" data-popover-content="export"></i>
                        <div id="a2" class="hidden">
                            <div class="popover-body">
                            <button class="btn btn-sm btn-primary mx-auto">Download</button>
                            </div>
                        </div>
                </div>
                <div class="card-body mobileheight">
                    <div class="chart-bar text-center">
                        <canvas id="highpermorfingpie" height="300"></canvas>

                        <div id="highpermorfingpie-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul class="text-left">
                                <li class="label-secondary row">

                                    <div class="legend-label col-7 pad-l-0 "><strong>Region</strong></div>
                                    <div class="legend-data col-5"><strong>Amount</strong></div>
                                </li>
                                <?php getstatebusiness($sql, 'DESC'); ?>
                            </ul>

                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="highregion" style="outline:none"> View
                            Data</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Product</h6>
                </div>
                <div class="card-body mobileheight">
                    <div class="chart-bar text-center">
                        <canvas id="highpermorfingproduct" height="300"></canvas>

                        <div id="highpermorfingproduct-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul class="text-left">
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0 "><strong>Product</strong></div>
                                    <div class="legend-data col-5"><strong>Amount</strong></div>
                                </li>
                                <?php getprodbusiness($sql, 'DESC'); ?>
                            </ul>

                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="highproduct" style="outline:none"> View
                            Data</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Category</h6>
                </div>
                <div class="card-body text-center mobileheight">
                    <div class="chart-bar">
                        <canvas id="highpermorfingcategory" height="300"></canvas>

                        <div id="highpermorfingcategory-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul class="text-left">
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0 "><strong>Category</strong></div>
                                 
                                    <div class="legend-data col-5"><strong>Amount</strong></div>
                                </li>
                                <?php getcatbusiness($sql, 'DESC'); ?>

                            </ul>

                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="highpercat" style="outline:none"> View
                            Data</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Low Performing Categories</h6>
                </div>
                <div class="card-body text-center mobileheight">
                    <div class="chart-bar">
                        <canvas id="lowpermorfingcategory" height="300px"></canvas>


                        <div id="lowpermorfingcategory-data" class="sale-status-legends sales-location"
                            style="display:none;">
                            <ul class="text-left">
                                <li class="label-secondary row">
                                    <div class="legend-label col-6 pad-l-0"><strong>Category</strong></div>
                                    <div class="legend-data col-3"><strong>Amount</strong></div>
                                </li>
                                <?php getcatbusiness($sql, 'ASC'); ?>
                            </ul>
                        </div>
                        <button class="btn-sm btn-primary mt-3 " id="lowperformcat" style="outline:none"> View
                            Data</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"> Month on Month Sales Performance %
                    </h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="myBarChart5"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Partners</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar info">
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>
                                <?php  getclientbusiness($sql, 'DESC'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Low Performing Partners</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar info" >
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>
                                <?php getclientbusiness($sql, 'ASC'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">High Performing Sales Executives</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar info" >
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>
                                <?php getpartnerbusiness($sql, 'DESC'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Low Performing Sales Executives</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar info">
                        <div class="sale-status-legends sales-location">
                            <ul>
                                <li class="label-secondary row">
                                    <div class="legend-label col-7 pad-l-0"><strong>Partner Name</strong></div>
                                    <div class="legend-data col-5"><strong>Sales</strong></div>
                                </li>
                                <?php getpartnerbusiness($sql, 'ASC'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>

</div>
<!-- /.container-fluid -->

<?php 

include('footer.php'); 
?>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>
<?php include('include/sales-dashboard-js.php'); ?>
<!-- <script src="js/demo/chart-pie.js"></script> -->
<script src="js/function.js"></script>

<script id="rendered-js">

</script>
<script>
    $(document).ready(function () {

        $('#highregion').click(function () {

            $('#highpermorfingpie').toggle();
            $('#highpermorfingpie-data').toggle();

            // $(this).text('View Chart');
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });

        $('#highproduct').click(function () {

            $('#highpermorfingproduct').toggle();
            $('#highpermorfingproduct-data').toggle();
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });


        $('#highpercat').click(function () {

            $('#highpermorfingcategory').toggle();
            $('#highpermorfingcategory-data').toggle();
            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });

        $('#lowperformcat').click(function () {

            $('#lowpermorfingcategory').toggle();
            $('#lowpermorfingcategory-data').toggle();

            $(this).text(function (i, text) {
                return text === "View Chart" ? "View Data" : "View Chart";
            })
        });

        
        $(function() {
        $("[data-toggle=popover]").popover({
            html: true,
            placement:"bottom",
            content: function() {
            var content = $(this).attr("data-popover-content");
            return $(content).children(".popover-body").html();
            },
            title: function() {
            var title = $(this).attr("data-popover-content");
            return $(title).children(".popover-heading").html();
            }
        });
});

    });
</script>




</body>

</html>