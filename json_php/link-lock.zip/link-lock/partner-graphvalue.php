<?php 
function zone_outstanding($sql, $zone) {
  
    $salesytd = mysqli_query($sql, "SELECT sum(outstanding) as amount  FROM `collection_import` where `zone` = '$zone'");
    $zoneamount = mysqli_fetch_object($salesytd);

    $zoneamount = round($zoneamount->amount);

    $english_format_number = number_format($zoneamount);

    return $zoneamount;

}

function zone_count($sql, $zoneid) {
  
    $salesytd = mysqli_query($sql, "SELECT id FROM `invoice` where zone = $zoneid group by client_id");
    $zoneamount = mysqli_num_rows($salesytd);

    return $zoneamount;

}


function zoneoutstanding_age($sql, $zone, $type) {
  
    $salesytd = mysqli_query($sql, "SELECT sum(from_zero) as zero, sum(from_four_six) as four, sum(from_six_one) as six, sum(from_nine_one) as nine, sum(from_twelve_one) as twelve, sum(from_fifteen_one) as fifteen, sum(greaterthan_eighteen_zero) as eighteen FROM `collection_import` where `zone` = '$zone'");
    $zoneamount = mysqli_fetch_object($salesytd);

    if($type == 1) {
        $amount = $zoneamount->zero + $zoneamount->four + $zoneamount->six;
    }

    if($type == 2) {
        $amount = $zoneamount->nine + $zoneamount->twelve + $zoneamount->fifteen;
    }

    if($type == 3) {
        $amount = $zoneamount->eighteen;
    }

    return $amount;

}

function zoneoutstanding_ageall($sql, $type) {
  
    $salesytd = mysqli_query($sql, "SELECT sum(from_zero) as zero, sum(from_four_six) as four, sum(from_six_one) as six, sum(from_nine_one) as nine, sum(from_twelve_one) as twelve, sum(from_fifteen_one) as fifteen, sum(greaterthan_eighteen_zero) as eighteen FROM `collection_import`");
    $zoneamount = mysqli_fetch_object($salesytd);

    if($type == 1) {
        $amount = $zoneamount->zero;
    }

    if($type == 2) {
        $amount = $zoneamount->four + $zoneamount->six;
    }

    if($type == 3) {
        $amount = $zoneamount->nine + $zoneamount->twelve + $zoneamount->fifteen;
    }

    if($type == 4) {
        $amount = $zoneamount->eighteen;
    }

    return $amount;

}

function total_outstanding($sql) {
  
    $salesytd = mysqli_query($sql, "SELECT sum(outstanding) as amount FROM `collection_import` ");
    $zoneamount = mysqli_fetch_object($salesytd);

    return round($zoneamount->amount, 0);

}

function product_group($sql) {

    $salesytd = mysqli_query($sql, "SELECT * FROM `product_group`");

    $group = "";
    while($getgroup = mysqli_fetch_object($salesytd)) {
        $group .= "'".$getgroup->title."',";
    }

    return $group;

}

function product_group_total($sql) {

    $salesytda = mysqli_query($sql, "SELECT * FROM `product_group`");

    $group = "";
    while($getgroupa = mysqli_fetch_object($salesytda)) {

        $pgid = $getgroupa->id;

        $salesytd = mysqli_query($sql, "SELECT sum(quantity) as qty FROM `product_cart` where pgid = '$pgid'");
        $pgidamount = mysqli_fetch_object($salesytd);

        $pgamount = round($pgidamount->qty);

        $group .= $pgamount.", ";
    }

    return $group;

}

function product_group_totalamt($sql) {

    $salesytda = mysqli_query($sql, "SELECT * FROM `product_group`");

    $group = "";
    while($getgroupa = mysqli_fetch_object($salesytda)) {

        $pgid = $getgroupa->id;

        $salesytd = mysqli_query($sql, "SELECT sum(amount_before_tax) as qty FROM `product_cart` where pgid = '$pgid'");
        $pgidamount = mysqli_fetch_object($salesytd);

        $pgamount = round($pgidamount->qty);

        $group .= $pgamount.", ";
    }

    return $group;

}

function getclientbusiness($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount) from `invoice` where client_id = c.id) as business FROM `client` as c order by business $permo LIMIT 5";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $x = 1;
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $clid = $listbuss->id;

        $getproducy = mysqli_query($sql, "SELECT pid, title, sum(quantity) as biz FROM `product_cart` as c LEFT JOIN `invoice` as i on i.invoice_no = c.invoice_no LEFT JOIN `product` as p on p.id = c.pid where i.client_id = $clid group by pid order by biz desc LIMIT 5");

        echo '<td style="vertical-align:top;">
        <table border="1" padding="3px" width="100%" class="low">
            <thead>
                <tr>
                    <th colspan="2" class="text-center">'.$listbuss->cname.'</th>
                </tr>
            </thead>
            <tbody >';

                while($listproduc = mysqli_fetch_object($getproducy)) {

                    echo '<tr>
                            <td class="colwidth" width="70%">'.$listproduc->title.'</td>
                            <td  width="30%">'.$listproduc->biz.'</td>
                        </tr>';
                }
                
            echo '</tbody>
        </table>
   
    </td>';

            $x++;

    }

}

function getclientbusiness_10name($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount) from `invoice` where client_id = c.id) as business FROM `client` as c order by business $permo LIMIT 10";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = '';
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $clid = $listbuss->id;
        $clname = $listbuss->cname;

        
        $xarrow .= "'".$clname."',";

    }

    return $xarrow;

}

function getclientbusiness_10biz($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount) from `invoice` where client_id = c.id) as business FROM `client` as c order by business $permo LIMIT 10";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = '';
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $clid = $listbuss->id;
        $clname = $listbuss->cname;

        
        $xarrow .= "'".$pgamount."',";

    }

    return $xarrow;

}

function getpartnerbusiness($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount) from `invoice` where executive = c.id) as business FROM `executive` as c order by business $permo LIMIT 10";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $x = 1;
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        if($x % 2 == 0)  {

            $classalt = 'alt';  

        }

        echo '<li class="label-secondary row '.$classalt.'">
                <div class="legend-label col-7 pad-l-0">'.$listbuss->ename.'</div>
                <div class="legend-data col-5">'.$pgamount.'</div>
            </li>';

            $x++;

    }

}

function getstatebusiness($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount) from `invoice` where `state` = c.id) as business FROM `state` as c order by business $permo LIMIT 5";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $x = 1;
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        if($x % 2 == 0)  {

            $classalt = 'alt';  

        }

        echo '<li class="label-secondary row '.$classalt.'">
                <div class="legend-label col-7 pad-l-0">'.$listbuss->title.'</div>
                <div class="legend-data col-5">'.$pgamount.'</div>
            </li>';

            $x++;

    }

}


function getstatebusiness_pie($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount) from `invoice` where `state` = c.id) as business FROM `state` as c order by business $permo LIMIT 5";

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = "";
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        $xarrow .= "'".$listbuss->title."', ";

    }

    return $xarrow;

}

function getstatebusiness_pieamount($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount) from `invoice` where `state` = c.id) as business FROM `state` as c order by business $permo LIMIT 5";

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = "";
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        $xarrow .= $pgamount.", ";

    }

    return $xarrow;

}

function getcatbusiness($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount_before_tax) from `product_cart` where `pcid` = c.id) as business FROM `product_category` as c order by business $permo LIMIT 5";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $x = 1;
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        if($x % 2 == 0)  {

            $classalt = 'alt';  

        }

        echo '<li class="label-secondary row '.$classalt.'">
                <div class="legend-label col-7 pad-l-0">'.$listbuss->title.'</div>
                <div class="legend-data col-5">'.$pgamount.'</div>
            </li>';

            $x++;

    }

}

function getprodbusiness($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount_before_tax) from `product_cart` where `pid` = c.id) as business FROM `product` as c order by business $permo LIMIT 5";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $x = 1;
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        if($x % 2 == 0)  {

            $classalt = 'alt';  

        }

        echo '<li class="label-secondary row '.$classalt.'">
                <div class="legend-label col-7 pad-l-0">'.$listbuss->title.'</div>
                <div class="legend-data col-5">'.$pgamount.'</div>
            </li>';

            $x++;

    }

}

function getprodbusiness_pie($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount_before_tax) from `product_cart` where `pid` = c.id) as business FROM `product` as c order by business $permo LIMIT 5";

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = '';
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        $xarrow .= "'".$listbuss->title."', ";

    }

    return $xarrow;

}

function getprodbusiness_pieamount($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount_before_tax) from `product_cart` where `pid` = c.id) as business FROM `product` as c order by business $permo LIMIT 5";

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = '';
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        $xarrow .= $pgamount.", ";

    }

    return $xarrow;

}


function getcatbusiness_pie($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount_before_tax) from `product_cart` where `pcid` = c.id) as business FROM `product_category` as c order by business $permo LIMIT 5";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = '';
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        $xarrow .= "'".$listbuss->title."', ";

    }

    return $xarrow;

}

function getcatbusiness_pieamount($sql, $permo) {

    $getclbus = "SELECT c.*, (SELECT sum(amount_before_tax) from `product_cart` where `pcid` = c.id) as business FROM `product_category` as c order by business $permo LIMIT 5";

    //echo $getclbus;

    $businsess = mysqli_query($sql, $getclbus);

    $xarrow = '';
    while($listbuss = mysqli_fetch_object($businsess)) {

        $pgamount = round($listbuss->business);
        $classalt = '';

        $xarrow .= $pgamount.", ";

    }

    return $xarrow;

}


function getmonthwise($sql, $permo, $year) {

    $getclbus = "SELECT sum(amount) as amount FROM `invoice` where `inv_date` like '".$year."-".$permo."%'";
    $businsess = mysqli_query($sql, $getclbus);

    $listbuss = mysqli_fetch_object($businsess);

    return round($listbuss->amount);

}



?>