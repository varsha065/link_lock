<?php
include('config.php');
include('header.php');
//include('module/viewrecords.php');
if(isset($_GET['lotno'])){
    $newlotno = $_GET['lotno'];
}

$start = 0;
$pstart = 1;
$limit = 100;
$nxtstart = 0;

$query = "SELECT * FROM `sales_import` where `lot` = '$newlotno'";

if(isset($_GET['start'])) {
    $pstart = mysqli_real_escape_string($sql, $_GET['start']);
    $nxtstart = ($limit * $pstart) + 1;
    $start = $pstart;
}

function paging($sql, $start, $limit, $query, $newlotno) {

    $getdistributor = mysqli_query($sql, $query);

    $getcount = mysqli_num_rows($getdistributor);

    $dividnum = $getcount / $limit;
    $ceilval = floor($dividnum);

    $first = $start + 1;
    $second = $start + 2; 
    $third = $start + 3;

    $flast = $ceilval - 3;
    $tlast = $ceilval - 2;
    $slast = $ceilval - 1;

    if($first > $flast) {
        $start = 0;
        $first = 1;
        $second = 2; 
        $third = 3;
    }

    echo '<nav aria-label="Page navigation example">
            <ul class="pagination justify-content-end">
                <li class="page-item">
                    <a class="page-link" href="?start=0&lotno='.$newlotno.'">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>';

                if($ceilval > 7) {

                    echo '<li class="page-item"><a class="page-link" href="?start='.$start.'&lotno='.$newlotno.'">'.$first.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$first.'&lotno='.$newlotno.'">'.$second.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$second.'&lotno='.$newlotno.'">'.$third.'</a></li>
                    <li class="page-item"><a class="page-link" href="lotno='.$newlotno.'">...</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$tlast.'&lotno='.$newlotno.'">'.$tlast.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$slast.'&lotno='.$newlotno.'">'.$slast.'</a></li>
                    <li class="page-item"><a class="page-link" href="?start='.$ceilval.'&lotno='.$newlotno.'">'.$ceilval.'</a></li>';

                } else {
                    for($x = $start; $x <= $ceilval; $x++){

                        $display = $x + 1;
    
                        echo '<li class="page-item"><a class="page-link" href="?start='.$x.'&lotno='.$newlotno.'">'.$display.'</a></li>';
                    }
                }


        echo '<li class="page-item">
                <a class="page-link" href="?start='.$ceilval.'&lotno='.$newlotno.'">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>';


}
?>
<style type="text/css">
  body, html {
    margin: 0;
    padding: 0;
    height: 100%;
  } 
  .scroller {
    overflow: scroll;
    padding: 5px;
    height: 100%;
  }
</style>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Import Excel Records : Lot No. - <?php echo $newlotno; ?></h1>

    

    <div class="row">

        <div class="col-xl-12 col-lg-12">
            <!-- Bar Chart -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Imported List of Excel</h6>
                </div>
                <div class="card-body scroller">
                <table class="table ">
                    <thead class="thead-dark">
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Product Group</th>
                        <th scope="col">Product Category</th>
                        <th scope="col">Product</th>
                        <th scope="col">Rate</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Invoice No</th>
                        <th scope="col">Invoice Date</th>
                        <th scope="col">City</th>
                        <th scope="col">State</th>
                        <th scope="col">Client Name</th>
                        <th scope="col">Discount 1</th>
                        <th scope="col">Discount 2</th>
                        <th scope="col">Discount 3</th>
                        <th scope="col">Commission</th>
                        <th scope="col">Amount Before Tax</th>
                        <th scope="col">Zone</th>
                        <th scope="col">Customer Group</th>
                        <th scope="col">Executive</th>
                        <th scope="col">Transport</th>
                        <th scope="col">GR No</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $lotquery = mysqli_query($sql, "SELECT * FROM `sales_import` where `lot` = '$newlotno' LIMIT $nxtstart, $limit");

                            if($nxtstart == 0) {
                                $x = 1;
                            } else {
                                $x = $nxtstart; 
                            }

                            while($listimport = mysqli_fetch_object($lotquery)) {

                                $invoicedate = date('d-m-Y', strtotime($listimport->inv_date));

                                echo '<tr>
                                    <th scope="row">'.$x.'</th>
                                    <td>'.$listimport->product_group.'</td>
                                    <td>'.$listimport->product_category.'</td>
                                    <td>'.$listimport->product.'</td>
                                    <td>'.$listimport->rate.'</td>
                                    <td>'.$listimport->quantity.'</td>
                                    <td>'.$listimport->invoice_no.'</td>
                                    <td>'.$invoicedate.'</td>
                                    <td>'.$listimport->city.'</td>
                                    <td>'.$listimport->state.'</td>
                                    <td>'.$listimport->client.'</td>
                                    <td>'.$listimport->discount_1.'</td>
                                    <td>'.$listimport->discount_2.'</td>
                                    <td>'.$listimport->discount_3.'</td>
                                    <td>'.$listimport->commission.'</td>
                                    <td>'.$listimport->amount_before_tax.'</td>
                                    <td>'.$listimport->zone.'</td>
                                    <td>'.$listimport->customer_group.'</td>
                                    <td>'.$listimport->executive.'</td>
                                    <td>'.$listimport->transport.'</td>
                                    <td>'.$listimport->gr_no.'</td>
                                </tr>';

                                $x++;

                            }
                        ?>
                    </tbody>
                    </table>
                    <?php paging($sql, $start, $limit, $query, $newlotno); ?>
                </div>
            </div>
        </div>

    </div>

</div>
<!-- /.container-fluid -->

<?php include('footer.php'); ?>


</body>

</html>