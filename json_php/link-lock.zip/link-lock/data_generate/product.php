<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT p.id as pgid, c.id as cid, s.product_group, s.product_category, s.product FROM `sales_import` as s 
LEFT JOIN product_group as p on p.title = s.product_group
LEFT JOIN product_category as c on c.title = s.product_category
group by s.product");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $product = $listquery->product;
    $pid = $listquery->pgid;
    $cid = $listquery->cid;

    mysqli_query($sql, "INSERT INTO `product` (`pgid`, `pcid`, `title`,  `cdate`) VALUE ('$pid', '$cid', '$product', '$cdate')");

}

?>