<?php

$dbHost = 'localhost';
$dbUser = 'project3_link';
$dbPass = '6Ujp#.zlMG!%';
$dbName = 'project3_link';
$port = 3306;

$sql= mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);

?> 
