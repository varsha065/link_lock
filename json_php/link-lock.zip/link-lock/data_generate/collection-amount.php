<?php

include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `collection_import`");

    //$businsess = mysqli_query($sql, $query);

    while($listbuss = mysqli_fetch_object($query)) {

        $outstanding = $listbuss->outstanding_due;
        $iid = $listbuss->id;

        $result = str_replace(',', '', $outstanding);

        

        mysqli_query($sql, "UPDATE `collection_import` SET `outstanding` = '$result' where `id` = '$iid'");

    }
?>