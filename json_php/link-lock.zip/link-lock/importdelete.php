<?php 
include('config.php');


if(isset($_GET['did'])) {

    $did = mysqli_real_escape_string($sql, $_GET['did']);

    mysqli_query($sql, "UPDATE `invoice_import_record` SET `deleted` = 1 where `id` = '$did'");

    echo '<script type="text/javascript">window.location.href="upload-excel.php"</script>';

}

if(isset($_GET['cdid'])) {

    $cdid = mysqli_real_escape_string($sql, $_GET['cdid']);

    mysqli_query($sql, "UPDATE `invoice_import_record` SET `deleted` = 1 where `id` = '$cdid'");

    echo '<script type="text/javascript">window.location.href="collection-excel.php"</script>';

}
?>