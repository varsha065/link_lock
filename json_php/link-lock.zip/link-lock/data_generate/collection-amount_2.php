<?php

include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT * FROM `collection_import`");

    //$businsess = mysqli_query($sql, $query);

    while($listbuss = mysqli_fetch_object($query)) {

        $from_zero = $listbuss->from_zero;
        $from_four_six = $listbuss->from_four_six;
        $from_six_one = $listbuss->from_six_one;
        $from_nine_one = $listbuss->from_nine_one;
        $from_twelve_one = $listbuss->from_twelve_one;
        $from_fifteen_one = $listbuss->from_fifteen_one;
        $greaterthan_eighteen_zero = $listbuss->greaterthan_eighteen_zero;
        $iid = $listbuss->id;

        $from_zero = str_replace(',', '', $from_zero);
        $from_four_six = str_replace(',', '', $from_four_six);
        $from_six_one = str_replace(',', '', $from_six_one);
        $from_nine_one = str_replace(',', '', $from_nine_one);
        $from_twelve_one = str_replace(',', '', $from_twelve_one);
        $from_fifteen_one = str_replace(',', '', $from_fifteen_one);
        $greaterthan_eighteen_zero = str_replace(',', '', $greaterthan_eighteen_zero);

        mysqli_query($sql, "UPDATE `collection_import` SET `from_zero` = '$from_zero', `from_four_six` = '$from_four_six', `from_six_one` = '$from_six_one', `from_nine_one` = '$from_nine_one', `from_twelve_one` = '$from_twelve_one', `from_fifteen_one` = '$from_fifteen_one', `greaterthan_eighteen_zero` = '$greaterthan_eighteen_zero' where `id` = '$iid'");

    }
?>