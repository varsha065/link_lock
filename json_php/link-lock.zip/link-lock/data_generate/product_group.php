<?php 
include('../database/DB.class.php');

$query = mysqli_query($sql, "SELECT product_group FROM `sales_import` group by product_group");

$cdate = date('Y-m-d H:i:s');

while($listquery = mysqli_fetch_object($query)){

    $pgroup = $listquery->product_group;

    mysqli_query($sql, "INSERT INTO `product_group` (`title`) VALUE ('$pgroup')");

}

?>